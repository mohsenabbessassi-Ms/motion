package com.example.motionrecorder

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var circle: Button
    private lateinit var status: TextView
    private val ui = Handler(Looper.getMainLooper())
    private var density = 1f

    private val poll = object : Runnable {
        override fun run() {
            refreshUi()
            ui.postDelayed(this, 300)
        }
    }

    private fun dp(v: Int) = (v * density).toInt()
    private fun t(key: String, vararg a: Any) = L.t(this, key, *a)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        density = resources.displayMetrics.density
        prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val fr = L.isFr(this)

        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val scroll = ScrollView(this).apply { addView(root) }
        // اتجاه الواجهة: يمين-يسار للعربية، يسار-يمين للفرنسية
        scroll.layoutDirection = if (fr) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
        setContentView(scroll)

        // ----- العنوان واللغة -----
        root.addView(TextView(this).apply {
            text = t("title")
            textSize = 22f
            gravity = Gravity.CENTER
        })

        root.addView(TextView(this).apply { text = t("language") })
        val langSpinner = Spinner(this)
        langSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, listOf("العربية", "Français")
        )
        val curLang = if (fr) 1 else 0
        langSpinner.setSelection(curLang)
        langSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != curLang) {
                    prefs.edit().putString("lang", if (pos == 1) "fr" else "ar").apply()
                    recreate()
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(langSpinner)

        // ----- الزر الدائري -----
        circle = Button(this).apply {
            textSize = 26f
            isAllCaps = false
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(dp(200), dp(200)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(16)
                bottomMargin = dp(8)
            }
            setOnClickListener { onCircleClick() }
        }
        root.addView(circle)

        status = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 16f
        }
        root.addView(status)

        // ----- الكاميرا والجودة والصوت -----
        addSection(root, t("sec_camera"))
        addSpinner(root, t("camera"), "camera", L.list(this, "camera_items"), 0)
        addSpinner(root, t("quality"), "quality", L.list(this, "quality_items"), 1)
        addCheck(root, t("audio"), "audio", true)
        addCheck(root, t("timestamp"), "timestamp", true)

        // ----- مكان الحفظ -----
        addSection(root, t("sec_storage"))
        val vols = MediaStore.getExternalVolumeNames(this).toList()
            .sortedBy { if (it == MediaStore.VOLUME_EXTERNAL_PRIMARY) 0 else 1 }
        val labels = vols.map {
            if (it == MediaStore.VOLUME_EXTERNAL_PRIMARY) t("vol_internal") else t("vol_sd", it)
        }
        val volSpinner = Spinner(this)
        volSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val savedVol = prefs.getString("volume", MediaStore.VOLUME_EXTERNAL_PRIMARY)
        volSpinner.setSelection(vols.indexOf(savedVol).coerceAtLeast(0))
        volSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("volume", vols[pos]).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(volSpinner)
        if (vols.size == 1) addNote(root, t("no_sd"))
        addNote(root, t("path_note"))

        // ----- أسباب التسجيل -----
        addSection(root, t("sec_triggers"))
        addCheck(root, t("trig_motion"), "trig_motion", true)
        addSeek(root, t("motion_sens"), "motion_sens", 60)
        addCheck(root, t("trig_sound"), "trig_sound", false)
        addSeek(root, t("sound_sens"), "sound_sens", 60)
        addCheck(root, t("trig_light"), "trig_light", true)
        addSeek(root, t("light_sens"), "light_sens", 50)

        // ----- مدة التسجيل بعد انتهاء السبب -----
        addSection(root, t("sec_post"))
        addSpinner(root, t("post_label"), "post_idx", L.list(this, "post_items"), 1)

        // ----- الجدول الزمني -----
        addSection(root, t("sec_schedule"))
        addCheck(root, t("schedule_on"), "schedule_on", false)
        val dayNames = L.list(this, "days")
        for (d in 0..6) {
            val cb = CheckBox(this)
            cb.text = dayNames[d]
            cb.isChecked = ((prefs.getInt("days_mask", 127) shr d) and 1) == 1
            cb.setOnCheckedChangeListener { _, checked ->
                var m = prefs.getInt("days_mask", 127)
                m = if (checked) m or (1 shl d) else m and (1 shl d).inv()
                prefs.edit().putInt("days_mask", m).apply()
            }
            root.addView(cb)
        }
        addTimeButton(root, t("from"), "start_min", 22 * 60)
        addTimeButton(root, t("to"), "end_min", 6 * 60)
        addNote(root, t("sched_note"))

        // ----- الخلفية والبطارية -----
        addSection(root, t("sec_bg"))
        root.addView(Button(this).apply {
            text = t("battery_btn")
            isAllCaps = false
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })
        addNote(root, t("battery_note"))

        addSection(root, t("sec_notes"))
        addNote(root, t("notes"))
    }

    override fun onResume() {
        super.onResume()
        ui.post(poll)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(poll)
    }

    // =====================================================================
    // الزر الدائري
    // =====================================================================

    private fun onCircleClick() {
        if (RecorderService.state != RecorderService.ST_IDLE) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
        } else {
            ensurePermissionsAndStart()
        }
    }

    private fun ensurePermissionsAndStart() {
        val need = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startMonitoring() else requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startMonitoring()
        } else {
            Toast.makeText(this, t("perm_camera"), Toast.LENGTH_LONG).show()
        }
    }

    private fun startMonitoring() {
        // عدّ تنازلي 30 ثانية فقط إذا لم يتم تحديد جدول زمني
        val countdown = if (prefs.getBoolean("schedule_on", false)) 0 else 30
        startForegroundService(
            Intent(this, RecorderService::class.java).putExtra(RecorderService.EXTRA_COUNTDOWN, countdown)
        )
    }

    private fun refreshUi() {
        when (RecorderService.state) {
            RecorderService.ST_COUNTDOWN -> {
                circle.text = RecorderService.countdownShown.toString()
                setCircleColor(0xFFF57C00.toInt())
                status.text = t("cancel_countdown")
            }
            RecorderService.ST_RUNNING -> {
                circle.text = t("stop")
                setCircleColor(0xFFD32F2F.toInt())
                status.text = RecorderService.statusText
            }
            else -> {
                circle.text = t("start")
                setCircleColor(0xFF388E3C.toInt())
                status.text = t("stopped")
            }
        }
    }

    private fun setCircleColor(color: Int) {
        circle.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
    }

    // =====================================================================
    // عناصر الواجهة المساعدة
    // =====================================================================

    private fun addSection(root: LinearLayout, text: String) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = 18f
            setPadding(0, dp(20), 0, dp(4))
        })
    }

    private fun addNote(root: LinearLayout, text: String) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.GRAY)
        })
    }

    private fun addCheck(root: LinearLayout, text: String, key: String, def: Boolean) {
        val cb = CheckBox(this)
        cb.text = text
        cb.isChecked = prefs.getBoolean(key, def)
        cb.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
        root.addView(cb)
    }

    private fun addSpinner(root: LinearLayout, label: String, key: String, items: List<String>, def: Int) {
        root.addView(TextView(this).apply { text = label })
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(prefs.getInt(key, def).coerceIn(0, items.size - 1))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt(key, pos).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(sp)
    }

    private fun addSeek(root: LinearLayout, label: String, key: String, def: Int) {
        val tv = TextView(this)
        val sb = SeekBar(this)
        sb.max = 100
        val v = prefs.getInt(key, def)
        sb.progress = v
        tv.text = "$label: $v%"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = "$label: $p%"
                prefs.edit().putInt(key, p).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(tv)
        root.addView(sb)
    }

    private fun addTimeButton(root: LinearLayout, prefix: String, key: String, defMin: Int) {
        val b = Button(this)
        fun fmt(m: Int) = String.format(Locale.US, "%02d:%02d", m / 60, m % 60)
        b.text = "$prefix ${fmt(prefs.getInt(key, defMin))}"
        b.setOnClickListener {
            val cur = prefs.getInt(key, defMin)
            TimePickerDialog(this, { _, h, m ->
                prefs.edit().putInt(key, h * 60 + m).apply()
                b.text = "$prefix ${fmt(h * 60 + m)}"
            }, cur / 60, cur % 60, true).show()
        }
        root.addView(b)
    }
}
