package com.example.motionrecorder

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraEffect
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.effects.OverlayEffect
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class RecorderService : LifecycleService() {

    companion object {
        const val TAG = "MotionRec"
        const val ACTION_STOP = "com.example.motionrecorder.STOP"
        const val EXTRA_COUNTDOWN = "countdown"
        const val CHANNEL_ID = "motion_rec"
        const val NOTIF_ID = 1

        const val ST_IDLE = 0
        const val ST_COUNTDOWN = 1
        const val ST_RUNNING = 2

        @Volatile var state = ST_IDLE
        @Volatile var countdownShown = 0
        @Volatile var statusText = ""

        // مدد التسجيل بعد انتهاء السبب (بالثواني)
        val POST_SECONDS = intArrayOf(10, 30, 300, 600, 900, 1200, 1800, 2700, 3600)
    }

    private val main = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null

    private var cameraProvider: ProcessCameraProvider? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var overlay: OverlayEffect? = null
    private var overlayThread: HandlerThread? = null
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private var micThread: Thread? = null
    @Volatile private var micRunning = false

    // ----- الإعدادات -----
    private var front = false
    private var qualityIdx = 1
    private var audioOn = true
    private var trigMotion = true
    private var trigSound = false
    private var trigLight = true
    private var motionSens = 60
    private var soundSens = 60
    private var lightSens = 50
    private var postMs = 30_000L
    private var timestampOn = true
    private var volume = MediaStore.VOLUME_EXTERNAL_PRIMARY
    private var scheduleOn = false
    private var daysMask = 127
    private var startMin = 22 * 60
    private var endMin = 6 * 60

    // ----- الحالة -----
    @Volatile private var armed = false
    @Volatile private var recActive = false
    @Volatile private var startPending = false
    @Volatile private var lastEvent = 0L
    private var pendingUnbind = false
    private var stopAfterFinalize = false

    // ----- حالة تحليل الصورة (خيط التحليل فقط) -----
    @Volatile private var resetRequested = true
    private var prev: IntArray? = null
    private var prevAvg = 0f
    private var baseline = 0f
    private var frames = 0
    private var hits = 0

    // =====================================================================
    // دورة حياة الخدمة
    // =====================================================================

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        if (intent?.action == ACTION_STOP) {
            if (recActive) {
                stopAfterFinalize = true
                recording?.stop()
                main.postDelayed({ stopSelf() }, 4000)
            } else {
                stopSelf()
            }
            return START_NOT_STICKY
        }

        createChannel()
        val n = buildNotification(L.t(this, "preparing"))
        if (Build.VERSION.SDK_INT >= 30) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (hasMic()) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(NOTIF_ID, n, t)
        } else {
            startForeground(NOTIF_ID, n)
        }

        if (state != ST_IDLE) return START_NOT_STICKY

        loadSettings()
        acquireWakeLock()

        val countdown = intent?.getIntExtra(EXTRA_COUNTDOWN, 0) ?: 0
        if (countdown > 0) {
            state = ST_COUNTDOWN
            countdownLeft = countdown
            main.post(countdownTick)
        } else {
            beginRunning()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        state = ST_IDLE
        statusText = ""
        main.removeCallbacksAndMessages(null)
        stopMicMonitor()
        try { recording?.stop() } catch (e: Exception) { Log.e(TAG, "stop", e) }
        try { cameraProvider?.unbindAll() } catch (e: Exception) { Log.e(TAG, "unbind", e) }
        closeOverlay()
        analysisExecutor.shutdown()
        try { wakeLock?.release() } catch (e: Exception) { }
        super.onDestroy()
    }

    // =====================================================================
    // العد التنازلي وبدء المراقبة
    // =====================================================================

    private var countdownLeft = 0

    private val countdownTick = object : Runnable {
        override fun run() {
            if (state != ST_COUNTDOWN) return
            if (countdownLeft <= 0) {
                beginRunning()
            } else {
                countdownShown = countdownLeft
                refreshStatus()
                countdownLeft--
                main.postDelayed(this, 1000)
            }
        }
    }

    private fun beginRunning() {
        state = ST_RUNNING
        main.removeCallbacks(ticker)
        main.post(ticker)
    }

    // كل ثانية: فحص الجدول الزمني، وإنهاء التسجيل عند انتهاء المدة
    private val ticker = object : Runnable {
        override fun run() {
            if (state != ST_RUNNING) return
            val should = scheduleAllows()
            if (should && !armed) {
                armed = true
                bindCamera()
                startMicIfNeeded()
                refreshStatus()
            } else if (!should && armed) {
                armed = false
                stopMicMonitor()
                if (recActive) {
                    pendingUnbind = true
                    recording?.stop()
                } else {
                    unbindCamera()
                }
                refreshStatus()
            }
            if (recActive && SystemClock.elapsedRealtime() - lastEvent >= postMs) {
                recording?.stop()
            }
            main.postDelayed(this, 1000)
        }
    }

    private fun scheduleAllows(): Boolean {
        if (!scheduleOn) return true
        val cal = Calendar.getInstance()
        val dow = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0 = الأحد
        val prevDow = (dow + 6) % 7
        val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val todayOn = ((daysMask shr dow) and 1) == 1
        val yesterdayOn = ((daysMask shr prevDow) and 1) == 1
        if (startMin == endMin) return todayOn
        return if (startMin < endMin) {
            todayOn && nowMin >= startMin && nowMin < endMin
        } else {
            (todayOn && nowMin >= startMin) || (yesterdayOn && nowMin < endMin)
        }
    }

    // =====================================================================
    // الإعدادات
    // =====================================================================

    private fun loadSettings() {
        val p = getSharedPreferences("settings", MODE_PRIVATE)
        front = p.getInt("camera", 0) == 1
        qualityIdx = p.getInt("quality", 1)
        audioOn = p.getBoolean("audio", true) && hasMic()
        trigMotion = p.getBoolean("trig_motion", true)
        trigSound = p.getBoolean("trig_sound", false)
        trigLight = p.getBoolean("trig_light", true)
        motionSens = p.getInt("motion_sens", 60)
        soundSens = p.getInt("sound_sens", 60)
        lightSens = p.getInt("light_sens", 50)
        val idx = p.getInt("post_idx", 1).coerceIn(0, POST_SECONDS.size - 1)
        postMs = POST_SECONDS[idx] * 1000L
        timestampOn = p.getBoolean("timestamp", true)
        volume = p.getString("volume", MediaStore.VOLUME_EXTERNAL_PRIMARY)
            ?: MediaStore.VOLUME_EXTERNAL_PRIMARY
        scheduleOn = p.getBoolean("schedule_on", false)
        daysMask = p.getInt("days_mask", 127)
        startMin = p.getInt("start_min", 22 * 60)
        endMin = p.getInt("end_min", 6 * 60)
    }

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "motionrecorder:wl").also {
            it.acquire()
        }
    }

    // =====================================================================
    // الكاميرا
    // =====================================================================

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                if (!armed || state != ST_RUNNING) return@addListener
                try {
                    bindUseCases(provider, timestampOn)
                } catch (e: Exception) {
                    Log.e(TAG, "bind failed (overlay=$timestampOn)", e)
                    if (timestampOn) bindUseCases(provider, false) else throw e
                }
            } catch (e: Exception) {
                Log.e(TAG, "camera error", e)
                statusText = L.t(this, "cam_error")
                notifyText(statusText)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindUseCases(provider: ProcessCameraProvider, withOverlay: Boolean) {
        provider.unbindAll()
        closeOverlay()

        val q = when (qualityIdx) {
            0 -> Quality.LOWEST
            2 -> Quality.HD
            3 -> Quality.FHD
            else -> Quality.SD
        }
        val recorder = Recorder.Builder()
            .setQualitySelector(QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q)))
            .build()
        val vc = VideoCapture.withOutput(recorder)

        val analysis = ImageAnalysis.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(320, 240),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                        )
                    ).build()
            )
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
        analysis.setAnalyzer(analysisExecutor, analyzer)

        val gb = UseCaseGroup.Builder().addUseCase(vc).addUseCase(analysis)
        if (withOverlay) gb.addEffect(createOverlay())

        val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        provider.bindToLifecycle(this@RecorderService, selector, gb.build())
        videoCapture = vc
        resetRequested = true
    }

    private fun unbindCamera() {
        try { cameraProvider?.unbindAll() } catch (e: Exception) { Log.e(TAG, "unbind", e) }
        videoCapture = null
        closeOverlay()
    }

    // ----- ختم التاريخ والوقت أسفل يمين الفيديو -----
    private fun createOverlay(): OverlayEffect {
        val ht = HandlerThread("overlay").also { it.start() }
        overlayThread = ht
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.DEFAULT_BOLD
        }
        val bgPaint = Paint().apply { color = 0x99000000.toInt() }

        val effect = OverlayEffect(CameraEffect.VIDEO_CAPTURE, 0, Handler(ht.looper)) { t ->
            Log.e(TAG, "overlay error", t)
        }
        effect.setOnDrawListener { frame ->
            val c = frame.overlayCanvas
            c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
            val text = fmt.format(Date())
            textPaint.textSize = min(c.width, c.height) * 0.05f
            val tw = textPaint.measureText(text)
            val pad = textPaint.textSize * 0.4f
            val right = c.width - pad * 1.5f
            val baseY = c.height - pad * 1.5f
            val fm = textPaint.fontMetrics
            c.drawRect(
                right - tw - pad / 2, baseY + fm.ascent - pad / 2,
                right + pad / 2, baseY + fm.descent + pad / 2, bgPaint
            )
            c.drawText(text, right - tw, baseY, textPaint)
            true
        }
        overlay = effect
        return effect
    }

    private fun closeOverlay() {
        try { overlay?.close() } catch (e: Exception) { }
        overlay = null
        overlayThread?.quitSafely()
        overlayThread = null
    }

    // =====================================================================
    // كشف الحركة وتغير الضوء
    // =====================================================================

    private val analyzer = ImageAnalysis.Analyzer { image ->
        try {
            analyze(image)
        } catch (e: Exception) {
            Log.e(TAG, "analyze", e)
        } finally {
            image.close()
        }
    }

    private fun analyze(image: ImageProxy) {
        if (!trigMotion && !trigLight) return
        val plane = image.planes[0]
        val buf = plane.buffer
        val rs = plane.rowStride
        val step = 8
        val cols = image.width / step
        val rows = image.height / step
        val n = cols * rows
        if (n <= 0) return

        val cur = IntArray(n)
        var sum = 0L
        var i = 0
        for (r in 0 until rows) {
            val base = r * step * rs
            for (c in 0 until cols) {
                val v = buf.get(base + c * step).toInt() and 0xFF
                cur[i++] = v
                sum += v
            }
        }
        val avg = sum.toFloat() / n

        if (resetRequested) {
            resetRequested = false
            frames = 0
            prev = null
            hits = 0
        }
        frames++
        val p = prev
        if (frames <= 15 || p == null) {
            prev = cur
            prevAvg = avg
            baseline = avg
            return
        }

        var motion = false
        if (trigMotion) {
            val shift = avg - prevAvg // لتجاهل تغير الإضاءة العام
            val pixThr = 40f - motionSens * 0.25f
            var changed = 0
            for (k in 0 until n) {
                if (abs(cur[k] - p[k] - shift) > pixThr) changed++
            }
            motion = changed.toFloat() / n > 0.20f - (motionSens / 100f) * 0.19f
        }

        var light = false
        if (trigLight) {
            val thr = 30f - lightSens * 0.27f
            light = abs(avg - baseline) > thr
        }

        baseline += (avg - baseline) * 0.02f
        prev = cur
        prevAvg = avg

        if (motion || light) hits++ else hits = 0
        if (hits >= 2) triggered()
    }

    private fun triggered() {
        lastEvent = SystemClock.elapsedRealtime()
        if (armed && !recActive && !startPending) {
            startPending = true
            main.post { startRecording() }
        }
    }

    // =====================================================================
    // كشف الصوت (قبل التسجيل، أو دائماً إذا كان الصوت غير مسجل في الفيديو)
    // =====================================================================

    private fun soundThreshold() = 0.30f - (soundSens / 100f) * 0.28f

    private fun startMicIfNeeded() {
        if (armed && trigSound && hasMic() && !(recActive && audioOn)) startMicMonitor()
    }

    @SuppressLint("MissingPermission")
    private fun startMicMonitor() {
        if (micThread?.isAlive == true) return
        micRunning = true
        micThread = Thread {
            val rate = 16000
            val minBuf = AudioRecord.getMinBufferSize(
                rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = try {
                AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    max(minBuf, 4096) * 2
                )
            } catch (e: Exception) {
                Log.e(TAG, "mic", e)
                return@Thread
            }
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                return@Thread
            }
            rec.startRecording()
            val buf = ShortArray(1600)
            var h = 0
            while (micRunning) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                if (n > 0) {
                    var peak = 0
                    for (k in 0 until n) {
                        val a = abs(buf[k].toInt())
                        if (a > peak) peak = a
                    }
                    if (peak / 32768f > soundThreshold()) {
                        h++
                        if (h >= 2) triggered()
                    } else {
                        h = 0
                    }
                }
            }
            try { rec.stop() } catch (e: Exception) { }
            rec.release()
        }.also { it.start() }
    }

    private fun stopMicMonitor() {
        micRunning = false
        try { micThread?.join(1000) } catch (e: InterruptedException) { }
        micThread = null
    }

    // =====================================================================
    // التسجيل
    // =====================================================================

    @SuppressLint("MissingPermission")
    private fun startRecording() {
        startPending = false
        if (!armed || recActive) return
        val vc = videoCapture ?: return

        val name = "VID_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val vols = MediaStore.getExternalVolumeNames(this)
        val vol = if (vols.contains(volume)) volume else MediaStore.VOLUME_EXTERNAL_PRIMARY

        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MotionRecorder")
        }
        val opts = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.getContentUri(vol)
        ).setContentValues(cv).setFileSizeLimit(1L shl 30).build()

        try {
            if (audioOn) stopMicMonitor()
            var pr = vc.output.prepareRecording(this, opts)
            if (audioOn) pr = pr.withAudioEnabled()
            recording = pr.start(ContextCompat.getMainExecutor(this)) { ev -> onRecordEvent(ev) }
            recActive = true
            refreshStatus()
        } catch (e: Exception) {
            Log.e(TAG, "start recording", e)
            recActive = false
            startMicIfNeeded()
        }
    }

    private fun onRecordEvent(ev: VideoRecordEvent) {
        when (ev) {
            is VideoRecordEvent.Status -> {
                if (trigSound && audioOn) {
                    var a = ev.recordingStats.audioStats.audioAmplitude.toDouble()
                    if (a > 1.5) a /= 32767.0
                    if (a > soundThreshold()) lastEvent = SystemClock.elapsedRealtime()
                }
            }
            is VideoRecordEvent.Finalize -> {
                recActive = false
                recording = null
                if (ev.hasError()) Log.e(TAG, "finalize error code=${ev.error}")
                if (stopAfterFinalize) {
                    stopSelf()
                    return
                }
                val again = ev.error == VideoRecordEvent.Finalize.ERROR_FILE_SIZE_LIMIT_REACHED &&
                        armed && SystemClock.elapsedRealtime() - lastEvent < postMs
                if (pendingUnbind) {
                    pendingUnbind = false
                    unbindCamera()
                }
                if (again) {
                    startRecording()
                } else {
                    startMicIfNeeded()
                    refreshStatus()
                }
            }
            else -> {}
        }
    }

    // =====================================================================
    // الإشعار
    // =====================================================================

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, L.t(this, "channel_name"), NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun refreshStatus() {
        statusText = when {
            state == ST_COUNTDOWN -> L.t(this, "countdown_status", countdownShown)
            recActive -> L.t(this, "recording")
            armed -> L.t(this, "watching")
            else -> L.t(this, "waiting")
        }
        notifyText(statusText)
    }

    private fun notifyText(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle(L.t(this, "title"))
            .setContentText(text)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, L.t(this, "stop"), stop)
            .setOngoing(true)
            .build()
    }
}
