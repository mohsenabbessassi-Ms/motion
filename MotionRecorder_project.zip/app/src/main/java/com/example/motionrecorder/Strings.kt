package com.example.motionrecorder

import android.content.Context

/**
 * الترجمات: index 0 = العربية، index 1 = الفرنسية
 * اللغة محفوظة في الإعدادات تحت المفتاح "lang" ("ar" أو "fr")
 */
object L {

    fun isFr(ctx: Context): Boolean =
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).getString("lang", "ar") == "fr"

    private val S: Map<String, Array<String>> = mapOf(
        "title" to arrayOf("مسجل الحركة", "Enregistreur de mouvement"),
        "language" to arrayOf("اللغة / Langue", "Langue / اللغة"),

        "sec_camera" to arrayOf("الكاميرا والفيديو", "Caméra et vidéo"),
        "camera" to arrayOf("الكاميرا", "Caméra"),
        "quality" to arrayOf("جودة الفيديو", "Qualité vidéo"),
        "audio" to arrayOf("تسجيل الصوت مع الفيديو", "Enregistrer le son avec la vidéo"),
        "timestamp" to arrayOf(
            "كتابة التاريخ والوقت أسفل الفيديو على اليمين",
            "Afficher la date et l'heure en bas à droite de la vidéo"
        ),

        "sec_storage" to arrayOf("مكان الحفظ", "Emplacement de stockage"),
        "vol_internal" to arrayOf("الذاكرة الداخلية", "Mémoire interne"),
        "vol_sd" to arrayOf("بطاقة الذاكرة (%s)", "Carte mémoire (%s)"),
        "no_sd" to arrayOf(
            "لم تُكتشف بطاقة ذاكرة. ستُحفظ الفيديوهات في الذاكرة الداخلية.",
            "Aucune carte mémoire détectée. Les vidéos seront enregistrées dans la mémoire interne."
        ),
        "path_note" to arrayOf(
            "المسار: Movies/MotionRecorder (يظهر في المعرض وفي تطبيق ملفاتي)",
            "Dossier : Movies/MotionRecorder (visible dans la Galerie et dans Mes fichiers)"
        ),

        "sec_triggers" to arrayOf(
            "أسباب بدء التسجيل (اختر واحداً أو أكثر)",
            "Déclencheurs d'enregistrement (un ou plusieurs)"
        ),
        "trig_motion" to arrayOf("حركة", "Mouvement"),
        "motion_sens" to arrayOf("حساسية الحركة", "Sensibilité au mouvement"),
        "trig_sound" to arrayOf("صوت", "Son"),
        "sound_sens" to arrayOf("حساسية الصوت", "Sensibilité au son"),
        "trig_light" to arrayOf("تغير الضوء", "Changement de lumière"),
        "light_sens" to arrayOf("حساسية الضوء", "Sensibilité à la lumière"),

        "sec_post" to arrayOf(
            "مدة التسجيل بعد انتهاء السبب",
            "Durée d'enregistrement après la fin du déclencheur"
        ),
        "post_label" to arrayOf(
            "يستمر التسجيل بعد آخر حركة/صوت/تغير ضوء لمدة",
            "L'enregistrement continue après le dernier mouvement/son/changement de lumière pendant"
        ),

        "sec_schedule" to arrayOf(
            "أيام وساعات التشغيل التلقائي",
            "Jours et heures de fonctionnement automatique"
        ),
        "schedule_on" to arrayOf(
            "تحديد أيام وساعات (إذا لم تحدد: يعمل دائماً بعد عدّ تنازلي 30 ثانية)",
            "Définir jours et heures (sinon : fonctionne en continu après un compte à rebours de 30 secondes)"
        ),
        "from" to arrayOf("من الساعة", "De"),
        "to" to arrayOf("إلى الساعة", "À"),
        "sched_note" to arrayOf(
            "إذا كانت ساعة النهاية أصغر من البداية فالفترة تمتد عبر منتصف الليل (مثلاً 22:00 إلى 06:00).",
            "Si l'heure de fin est inférieure à l'heure de début, la période passe minuit (ex. 22:00 à 06:00)."
        ),

        "sec_bg" to arrayOf(
            "العمل في الخلفية والشاشة مغلقة",
            "Fonctionnement en arrière-plan, écran éteint"
        ),
        "battery_btn" to arrayOf(
            "إعدادات البطارية: اجعل التطبيق غير مقيّد",
            "Batterie : mettre l'application en « Non restreint »"
        ),
        "battery_note" to arrayOf(
            "في سامسونج: الإعدادات ← البطارية ← حدود استخدام الخلفية ← أزل التطبيق من التطبيقات النائمة.",
            "Sur Samsung : Paramètres → Batterie → Limites d'utilisation en arrière-plan → retirez l'application des applications en veille."
        ),

        "sec_notes" to arrayOf("ملاحظات", "Remarques"),
        "notes" to arrayOf(
            "صيغة الفيديو: MP4 (الأفضل والأكثر توافقاً). التغييرات تُطبَّق عند الضغط على الزر الدائري.",
            "Format vidéo : MP4 (le plus compatible). Les changements s'appliquent en appuyant sur le bouton rond."
        ),

        "cancel_countdown" to arrayOf("اضغط لإلغاء العد التنازلي", "Appuyez pour annuler le compte à rebours"),
        "stop" to arrayOf("إيقاف", "Arrêter"),
        "start" to arrayOf("ابدأ", "Démarrer"),
        "stopped" to arrayOf("متوقف", "Arrêté"),
        "perm_camera" to arrayOf(
            "إذن الكاميرا مطلوب لتشغيل التطبيق",
            "L'autorisation de la caméra est requise"
        ),

        // الخدمة والإشعار
        "preparing" to arrayOf("جارٍ التجهيز...", "Préparation..."),
        "cam_error" to arrayOf("تعذر تشغيل الكاميرا", "Impossible de démarrer la caméra"),
        "countdown_status" to arrayOf("يبدأ بعد %d ثانية", "Démarrage dans %d s"),
        "recording" to arrayOf("● جارٍ التسجيل", "● Enregistrement en cours"),
        "watching" to arrayOf("قيد المراقبة", "Surveillance active"),
        "waiting" to arrayOf("في انتظار موعد التشغيل", "En attente de l'horaire programmé"),
        "channel_name" to arrayOf("المراقبة", "Surveillance")
    )

    private val LISTS: Map<String, Array<List<String>>> = mapOf(
        "camera_items" to arrayOf(
            listOf("الخلفية", "الأمامية"),
            listOf("Arrière", "Avant")
        ),
        "quality_items" to arrayOf(
            listOf("الأدنى (حوالي 360p حسب الهاتف)", "480p", "720p", "1080p"),
            listOf("La plus basse (≈360p selon le téléphone)", "480p", "720p", "1080p")
        ),
        "post_items" to arrayOf(
            listOf(
                "10 ثوانٍ", "30 ثانية", "5 دقائق", "10 دقائق", "15 دقيقة",
                "20 دقيقة", "30 دقيقة", "45 دقيقة", "60 دقيقة"
            ),
            listOf(
                "10 secondes", "30 secondes", "5 minutes", "10 minutes", "15 minutes",
                "20 minutes", "30 minutes", "45 minutes", "60 minutes"
            )
        ),
        "days" to arrayOf(
            listOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"),
            listOf("Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi")
        )
    )

    fun t(ctx: Context, key: String, vararg args: Any): String {
        val s = S[key]?.get(if (isFr(ctx)) 1 else 0) ?: key
        return if (args.isEmpty()) s else String.format(s, *args)
    }

    fun list(ctx: Context, key: String): List<String> =
        LISTS[key]?.get(if (isFr(ctx)) 1 else 0) ?: emptyList()
}
